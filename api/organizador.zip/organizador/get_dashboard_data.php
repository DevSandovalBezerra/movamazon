<?php
header('Content-Type: application/json; charset=utf-8');
error_log('[DASHBOARD] Iniciando API do dashboard');
require_once __DIR__ . '/../db.php';
session_start();

// Logs de depuração


if (!isset($_SESSION['user_id']) || !isset($_SESSION['papel']) || $_SESSION['papel'] !== 'organizador') {
    //error_log('[DASHBOARD] Acesso negado - user_id: ' . ($_SESSION['user_id'] ?? 'NÃO DEFINIDO') . ', papel: ' . ($_SESSION['papel'] ?? 'NÃO DEFINIDO'));
    echo json_encode(['success' => false, 'message' => 'Acesso negado']);
    exit;
}

$user_id = $_SESSION['user_id'];
//error_log('[DASHBOARD] Usuário autorizado: ' . $user_id);

try {
    //error_log('[DASHBOARD] Iniciando try/catch');

    // Buscar dados do organizador
    $stmt = $pdo->prepare('SELECT id, nome_completo FROM usuarios WHERE id = ?');
    $stmt->execute([$user_id]);
    $organizador = $stmt->fetch(PDO::FETCH_ASSOC);
    //error_log('[DASHBOARD] Organizador encontrado: ' . ($organizador ? 'SIM' : 'NÃO'));

    if (!$organizador) {
        echo json_encode(['success' => false, 'message' => 'Organizador não encontrado']);
        exit;
    }

    // Função para verificar se evento tem todas as etapas concluídas
    function eventoCompleto($pdo, $evento_id)
    {
        $checks = [
            'modalidades' => "SELECT COUNT(*) as count FROM modalidades WHERE evento_id = ? AND ativo = 1",
            'lotes' => "SELECT COUNT(*) as count FROM lotes_inscricao WHERE evento_id = ? AND ativo = 1",
            'kits' => "SELECT COUNT(*) as count FROM kits_eventos WHERE evento_id = ? AND ativo = 1",
            'produtos_extras' => "SELECT COUNT(*) as count FROM produtos_extras WHERE evento_id = ? AND ativo = 1",
            'tamanhos' => "SELECT COUNT(*) as count FROM camisas WHERE evento_id = ? AND ativo = 1",
            'programacao' => "SELECT COUNT(*) as count FROM programacao_evento WHERE evento_id = ? AND ativo = 1",
            'questionario' => "SELECT COUNT(*) as count FROM questionario_evento WHERE evento_id = ? AND ativo = 1",
            'retirada_kits' => "SELECT COUNT(*) as count FROM retirada_kits_evento WHERE evento_id = ? AND ativo = 1",
            'cupons' => "SELECT COUNT(*) as count FROM cupons_remessa WHERE evento_id = ? AND status = 'ativo'"
        ];

        foreach ($checks as $sqlCheck) {
            $stmt = $pdo->prepare($sqlCheck);
            $stmt->execute([$evento_id]);
            $count = (int)$stmt->fetch(PDO::FETCH_ASSOC)['count'];
            if ($count <= 0) {
                return false; // Evento incompleto
            }
        }
        return true; // Evento completo (9/9 etapas)
    }

    // Buscar eventos do organizador com dados completos (apenas eventos com todas as etapas)
    $stmt = $pdo->prepare('
        SELECT 
            e.id,
            e.nome as name,
            e.descricao,
            e.data_inicio as date,
            e.hora_inicio,
            e.local,
            e.cidade,
            e.estado,
            e.imagem as image,
            e.limite_vagas as maxRegistrations,
            e.status,
            COUNT(i.id) as registrations
        FROM eventos e
        LEFT JOIN inscricoes i ON e.id = i.evento_id
        WHERE e.organizador_id = ? AND e.deleted_at IS NULL
        GROUP BY e.id
        ORDER BY e.data_inicio DESC
    ');

    $stmt->execute([$user_id]);

    $eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    //error_log('[DASHBOARD] Eventos encontrados: ' . count($eventos));

    // Filtrar apenas eventos com todas as etapas concluídas (9/9)
    $eventosCompletos = [];
    foreach ($eventos as $evento) {
        if (eventoCompleto($pdo, $evento['id'])) {
            $eventosCompletos[] = $evento;
        }
    }

    //error_log('[DASHBOARD] Eventos completos (9/9 etapas): ' . count($eventosCompletos));

    // Calcular totais (apenas eventos completos)
    $totalEventos = count($eventosCompletos);
    $totalInscritos = array_sum(array_column($eventosCompletos, 'registrations'));

    // Calcular taxa de ocupação média (apenas eventos completos)
    $taxaOcupacao = 0;
    if ($totalEventos > 0) {
        $somaTaxas = 0;
        foreach ($eventosCompletos as $evento) {
            if ($evento['maxRegistrations'] > 0) {
                $somaTaxas += ($evento['registrations'] / $evento['maxRegistrations']) * 100;
            }
        }
        $taxaOcupacao = round($somaTaxas / $totalEventos, 1);
    }

    // Formatar dados para o frontend (apenas eventos completos)
    $eventosFormatados = [];
    foreach ($eventosCompletos as $evento) {
        $eventosFormatados[] = [
            'id' => $evento['id'],
            'name' => $evento['name'],
            'descricao' => $evento['descricao'],
            'date' => $evento['date'],
            'hora_inicio' => $evento['hora_inicio'],
            'local' => $evento['local'],
            'cidade' => $evento['cidade'] ?: '',
            'estado' => $evento['estado'] ?: '',
            'registrations' => (int)$evento['registrations'],
            'image' => $evento['image'] ?: 'default-event.jpg',
            'status' => $evento['status'] ?: 'ativo',
            'maxRegistrations' => (int)$evento['maxRegistrations'] ?: 1000
        ];
    }

    // Buscar atividades recentes (últimas 5 inscrições de eventos completos)
    $stmt = $pdo->prepare('
        SELECT 
            i.data_inscricao as data,
            CONCAT("Nova inscrição em ", e.nome) as titulo,
            "fa-user-plus" as icone
        FROM inscricoes i
        INNER JOIN eventos e ON i.evento_id = e.id
        WHERE e.organizador_id = ? AND e.deleted_at IS NULL
        ORDER BY i.data_inscricao DESC
        LIMIT 5
    ');
    $stmt->execute([$user_id]);
    $atividades = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Filtrar atividades apenas de eventos completos
    $atividadesCompletas = [];
    foreach ($atividades as $atividade) {
        // Extrair evento_id da atividade (precisamos fazer uma consulta adicional)
        $stmt = $pdo->prepare('
            SELECT e.id 
            FROM inscricoes i 
            INNER JOIN eventos e ON i.evento_id = e.id 
            WHERE i.data_inscricao = ? AND e.organizador_id = ? AND e.deleted_at IS NULL
            LIMIT 1
        ');
        $stmt->execute([$atividade['data'], $user_id]);
        $eventoAtividade = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($eventoAtividade && eventoCompleto($pdo, $eventoAtividade['id'])) {
            $atividadesCompletas[] = $atividade;
        }
    }

    $response = [
        'success' => true,
        'data' => [
            'organizador' => [
                'id' => $organizador['id'],
                'nome' => $organizador['nome_completo']
            ],
            'estatisticas' => [
                'totalEventos' => $totalEventos,
                'totalInscritos' => $totalInscritos,
                'taxaOcupacao' => $taxaOcupacao
            ],
            'eventos' => $eventosFormatados,
            'atividades' => $atividadesCompletas
        ]
    ];


    //error_log('[DASHBOARD] Resposta: ' . json_encode($response));
    echo json_encode($response);
} catch (Exception $e) {
    error_log('[DASHBOARD] ERRO: ' . $e->getMessage());
    error_log('[DASHBOARD] Stack trace: ' . $e->getTraceAsString());
    echo json_encode(['success' => false, 'message' => 'Erro ao carregar dados: ' . $e->getMessage()]);
}
