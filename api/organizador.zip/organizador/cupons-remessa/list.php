<?php
require_once '../../auth/auth.php';
require_once '../../db.php';
header('Content-Type: application/json');

if (!isOrganizador()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Acesso negado']);
    exit;
}

$evento_id = $_GET['evento_id'] ?? null;
$status = $_GET['status'] ?? null;
$data_inicio = $_GET['data_inicio'] ?? null;
$data_fim = $_GET['data_fim'] ?? null;

$where = ['1=1'];
$params = [];

$where[] = '(
    evento_id IS NULL OR evento_id IN (SELECT id FROM eventos WHERE organizador_id = ?)
)';
$params[] = $_SESSION['user_id'];

if ($evento_id) {
    $where[] = 'evento_id = ?';
    $params[] = $evento_id;
}
if ($status) {
    $where[] = 'status = ?';
    $params[] = $status;
}
if ($data_inicio) {
    $where[] = 'data_inicio >= ?';
    $params[] = $data_inicio;
}
if ($data_fim) {
    $where[] = 'data_validade <= ?';
    $params[] = $data_fim;
}

$sql = 'SELECT * FROM cupons_remessa WHERE ' . implode(' AND ', $where) . ' ORDER BY data_criacao DESC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$remessas = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo json_encode(['success' => true, 'remessas' => $remessas]); 
