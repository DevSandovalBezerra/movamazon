<?php
session_start();
require_once '../../db.php';

// Verificar autenticação
if (!isset($_SESSION['user_id']) || $_SESSION['papel'] !== 'organizador') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Acesso negado']);
    exit();
}

// Verificar se ID foi fornecido
$id = $_GET['id'] ?? null;
if (!$id) {
    echo json_encode(['success' => false, 'message' => 'ID do cupom não fornecido']);
    exit();
}

try {
    // Verificar se o cupom pertence ao organizador
    $stmt = $pdo->prepare('SELECT id FROM cupons_remessa WHERE id = ? AND (evento_id IS NULL OR evento_id IN (SELECT id FROM eventos WHERE organizador_id = ?))');
    $stmt->execute([$id, $_SESSION['user_id']]);
    
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Cupom não encontrado ou sem permissão']);
        exit();
    }
    
    // Verificar utilizações (simulado - em produção você verificaria na tabela inscricoes_cupons)
    // Por enquanto, vamos retornar 0 utilizações para permitir exclusão
    $utilizacoes = 0;
    
    echo json_encode([
        'success' => true,
        'utilizacoes' => $utilizacoes
    ]);
    
} catch (Exception $e) {
    error_log('Erro ao verificar utilizações do cupom: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Erro interno do servidor']);
}
?> 
