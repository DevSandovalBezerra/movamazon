<?php
session_start();
require_once '../../db.php';
require_once __DIR__ . '/../../helpers/organizador_context.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['papel'] !== 'organizador') {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit;
}

$ctx = requireOrganizadorContext($pdo);
$usuario_id = $ctx['usuario_id'];
$organizador_id = $ctx['organizador_id'];
$input = json_decode(file_get_contents('php://input'), true);
error_log('📊 Input: ' . json_encode($input));

if (!$input) {
    echo json_encode(['success' => false, 'message' => 'Dados inválidos']);
    exit;
}

$evento_id = $input['id'] ?? null;
$nome = $input['nome'] ?? null;
$categoria = $input['categoria'] ?? null;
$data_inicio = $input['data_inicio'] ?? null;
$hora_inicio = $input['hora_inicio'] ?? null;
$local = $input['local'] ?? null;
$cep = $input['cep'] ?? null;
$url_mapa = $input['url_mapa'] ?? null;
$logradouro = $input['logradouro'] ?? null;
$numero = $input['numero'] ?? null;
$cidade = $input['cidade'] ?? null;
$estado = $input['estado'] ?? null;
$pais = $input['pais'] ?? null;
$limite_vagas = $input['limite_vagas'] ?? null;
$data_fim_inscricoes = $input['data_fim'] ?? null;
$hora_fim_inscricoes = $input['hora_fim_inscricoes'] ?? null;
$taxa_gratuitas = $input['taxa_gratuitas'] ?? null;
$taxa_pagas = $input['taxa_pagas'] ?? null;
$taxa_setup = $input['taxa_setup'] ?? null;
$percentual_repasse = $input['percentual_repasse'] ?? null;
$exibir_retirada_kit = $input['exibir_retirada_kit'] ?? null;

if (!$evento_id || !$nome) {
    echo json_encode(['success' => false, 'message' => 'ID e nome do evento são obrigatórios']);
    exit;
}

try {
    // $pdo = getConnection();

    // Verificar se o evento pertence ao organizador (compatível com legado: organizador_id pode estar como usuarios.id)
    $stmt = $pdo->prepare("SELECT id FROM eventos WHERE id = ? AND (organizador_id = ? OR organizador_id = ?)");
    $stmt->execute([$evento_id, $organizador_id, $usuario_id]);
    $eventoCheck = $stmt->fetch(PDO::FETCH_ASSOC);
    error_log('📊 Evento encontrado: ' . json_encode($eventoCheck));
    if (!$eventoCheck) {
        echo json_encode(['success' => false, 'message' => 'Evento não encontrado ou não autorizado']);
        exit;
    }

    // Atualizar evento (com campos expandidos da Opção B)
    $stmt = $pdo->prepare("
        UPDATE eventos SET
            nome = ?,
            categoria = ?,
            data_inicio = ?,
            hora_inicio = ?,
            local = ?,
            cep = ?,
            url_mapa = ?,
            logradouro = ?,
            numero = ?,
            cidade = ?,
            estado = ?,
            pais = ?,
            limite_vagas = ?,
            data_fim = ?,
            hora_fim_inscricoes = ?,
            taxa_gratuitas = ?,
            taxa_pagas = ?,
            taxa_setup = ?,
            percentual_repasse = ?,
            exibir_retirada_kit = ?
        WHERE id = ?
    ");

    $stmt->execute([
        $nome,
        $categoria,
        $data_inicio,
        $hora_inicio,
        $local,
        $cep,
        $url_mapa,
        $logradouro,
        $numero,
        $cidade,
        $estado,
        $pais,
        $limite_vagas,
        $data_fim_inscricoes,
        $hora_fim_inscricoes,
        $taxa_gratuitas,
        $taxa_pagas,
        $taxa_setup,
        $percentual_repasse,
        $exibir_retirada_kit,
        $evento_id
    ]);

    // Buscar evento atualizado
    $stmt = $pdo->prepare("SELECT * FROM eventos WHERE id = ?");
    $stmt->execute([$evento_id]);
    $evento = $stmt->fetch(PDO::FETCH_ASSOC);
    error_log('📊 Evento atualizado: ' . json_encode($evento));
    echo json_encode([
        'success' => true,
        'data' => $evento
    ]);
} catch (PDOException $e) {
    error_log('Erro ao atualizar evento: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Erro interno do servidor']);
}
