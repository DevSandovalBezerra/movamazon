<?php
header('Content-Type: application/json');
require_once '../../db.php';
require_once '../../middleware/auth.php';
require_once __DIR__ . '/../../helpers/organizador_context.php';

// Verificar autenticação e permissões usando middleware centralizado
verificarAutenticacao('organizador');

try {
    $ctx = requireOrganizadorContext($pdo);
    $usuario_id = $ctx['usuario_id'];
    $organizador_id = $ctx['organizador_id'];
    $evento_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

    error_log('📡 API eventos/get.php - Buscando evento - ID: ' . $evento_id);
    error_log('📡 API eventos/get.php - Organizador ID da sessão: ' . $organizador_id);

    if (!$evento_id) {
        throw new Exception('ID do evento é obrigatório');
    }

    // Buscar dados do evento com informações do organizador
    $sql = "SELECT 
                e.id,
                e.nome,
                e.categoria,
                e.genero,
                e.descricao,
                e.data_inicio,
                e.data_fim,
                e.local,
                e.cep,
                e.url_mapa,
                e.logradouro,
                e.numero,
                e.cidade,
                e.estado,
                e.pais,
                e.regulamento,
                e.status,
                e.taxa_setup,
                e.taxa_gratuitas,
                e.limite_vagas,
                e.hora_fim_inscricoes,
                e.data_fim_inscricoes,
                e.taxa_pagas,
                e.percentual_repasse,
                e.exibir_retirada_kit,
                e.hora_inicio,
                e.imagem,
                e.data_criacao,
                e.data_realizacao,
                e.organizador_id,
                o.empresa as organizador_nome
            FROM eventos e
            LEFT JOIN organizadores o ON o.id = ?
            WHERE e.id = ?";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$organizador_id, $evento_id]);
    $evento = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$evento) {
        throw new Exception('Evento não encontrado');
    }

    error_log('📡 API eventos/get.php - Evento encontrado - Organizador ID: ' . $evento['organizador_id']);
    error_log('📡 API eventos/get.php - Organizador Nome: ' . ($evento['organizador_nome'] ?: 'VAZIO'));

    // Verificar se o organizador tem permissão para acessar este evento
    if ($evento['organizador_id'] != $organizador_id && $evento['organizador_id'] != $usuario_id) {
        error_log('📡 API eventos/get.php - ERRO: Organizador não autorizado');
        throw new Exception('Evento não autorizado');
    }

    // Formatar dados
    $evento['data_inicio_formatada'] = $evento['data_inicio'] ? date('Y-m-d', strtotime($evento['data_inicio'])) : '';
    $evento['data_fim_formatada'] = $evento['data_fim'] && $evento['data_fim'] !== '0000-00-00' ? date('Y-m-d', strtotime($evento['data_fim'])) : '';
    $evento['hora_inicio_formatada'] = $evento['hora_inicio'] ? date('H:i', strtotime($evento['hora_inicio'])) : '';

    // URL da imagem
    if ($evento['imagem']) {
        $evento['imagem_url'] = '../../assets/img/eventos/' . $evento['imagem'];
    } else {
        $evento['imagem_url'] = '../../assets/img/default-event.jpg';
    }

    error_log('✅ Evento encontrado: ' . $evento['nome']);
    error_log('🔍 DEBUG - Dados do evento retornados: ' . json_encode($evento));

    echo json_encode([
        'success' => true,
        'data' => $evento
    ]);
} catch (Exception $e) {
    error_log('💥 Erro ao buscar evento: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
