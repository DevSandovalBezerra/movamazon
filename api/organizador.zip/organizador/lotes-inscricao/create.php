<?php
session_start();
header('Content-Type: application/json');

// Verificar autenticação
if (!isset($_SESSION['user_id']) || $_SESSION['papel'] !== 'organizador') {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit();
}

require_once '../../db.php';
require_once __DIR__ . '/../../helpers/organizador_context.php';

try {
    $ctx = requireOrganizadorContext($pdo);
    $usuario_id = $ctx['usuario_id'];
    $organizador_id = $ctx['organizador_id'];

    // Validar dados obrigatórios (estrutura otimizada)
    $required_fields = ['evento_id', 'modalidade_id', 'numero_lote', 'preco', 'data_inicio', 'data_fim'];
    foreach ($required_fields as $field) {
        if (!isset($_POST[$field]) || empty($_POST[$field])) {
            throw new Exception("Campo obrigatório não informado: $field");
        }
    }

    $evento_id = (int)$_POST['evento_id'];
    $modalidade_id = (int)$_POST['modalidade_id'];
    $numero_lote = (int)$_POST['numero_lote'];
    $preco = (float)$_POST['preco'];
    $data_inicio = $_POST['data_inicio'];
    $data_fim = $_POST['data_fim'];
    $preco_por_extenso = $_POST['preco_por_extenso'] ?? '';
    $vagas_disponiveis = isset($_POST['vagas_disponiveis']) ? (int)$_POST['vagas_disponiveis'] : null;
    $taxa_servico = isset($_POST['taxa_servico']) ? (float)$_POST['taxa_servico'] : 0;
    $quem_paga_taxa = $_POST['quem_paga_taxa'] ?? 'participante';
    $idade_min = isset($_POST['idade_min']) ? (int)$_POST['idade_min'] : 0;
    $idade_max = isset($_POST['idade_max']) ? (int)$_POST['idade_max'] : 100;
    $desconto_idoso = isset($_POST['desconto_idoso']) ? (bool)$_POST['desconto_idoso'] : false;

    // Validar se o evento pertence ao organizador
    $stmt = $pdo->prepare("SELECT id FROM eventos WHERE id = ? AND (organizador_id = ? OR organizador_id = ?) AND deleted_at IS NULL");
    $stmt->execute([$evento_id, $organizador_id, $usuario_id]);
    if (!$stmt->fetch()) {
        throw new Exception('Evento não encontrado ou não autorizado');
    }

    // Validar datas
    if (strtotime($data_inicio) >= strtotime($data_fim)) {
        throw new Exception('Data de início deve ser anterior à data de fim');
    }

    // Tipo de público agora vem da categoria da modalidade (não precisa validar)

    // Validar quem paga taxa
    if (!in_array($quem_paga_taxa, ['organizador', 'participante'])) {
        throw new Exception('Quem paga taxa inválido');
    }

    // Validar se a modalidade pertence ao evento
    $stmt = $pdo->prepare("SELECT id FROM modalidades WHERE id = ? AND evento_id = ?");
    $stmt->execute([$modalidade_id, $evento_id]);
    if (!$stmt->fetch()) {
        throw new Exception('Modalidade não encontrada ou não pertence ao evento');
    }

    // Verificar se já existe lote com mesmo número para o evento e modalidade
    $stmt = $pdo->prepare("SELECT id FROM lotes_inscricao WHERE evento_id = ? AND modalidade_id = ? AND numero_lote = ?");
    $stmt->execute([$evento_id, $modalidade_id, $numero_lote]);
    if ($stmt->fetch()) {
        throw new Exception('Já existe um lote com este número para esta modalidade');
    }

    // Inserir lote (estrutura otimizada)
    $stmt = $pdo->prepare("
        INSERT INTO lotes_inscricao (
            evento_id, modalidade_id, numero_lote, preco, preco_por_extenso,
            data_inicio, data_fim, vagas_disponiveis, taxa_servico, quem_paga_taxa,
            idade_min, idade_max, desconto_idoso, ativo
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
    ");

    $stmt->execute([
        $evento_id, $modalidade_id, $numero_lote, $preco, $preco_por_extenso,
        $data_inicio, $data_fim, $vagas_disponiveis, $taxa_servico, $quem_paga_taxa,
        $idade_min, $idade_max, $desconto_idoso
    ]);

    $lote_id = $pdo->lastInsertId();

    error_log("✅ Lote de inscrição criado com ID: $lote_id");

    echo json_encode([
        'success' => true,
        'message' => 'Lote criado com sucesso',
        'lote_id' => $lote_id
    ]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    error_log("💥 Erro ao criar lote: " . $e->getMessage());
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?> 
