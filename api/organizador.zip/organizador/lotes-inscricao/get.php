<?php
session_start();
header('Content-Type: application/json');

// Verificar autenticação
if (!isset($_SESSION['user_id']) || $_SESSION['papel'] !== 'organizador') {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit();
}

require_once '../../db.php';

try {
    $lote_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    
    if (!$lote_id) {
        throw new Exception('ID do lote não informado');
    }

    // Buscar dados do lote (estrutura otimizada)
    $stmt = $pdo->prepare("
        SELECT 
            li.*,
            e.nome as evento_nome,
            m.nome as modalidade_nome,
            c.nome as categoria_nome,
            CONCAT(m.nome, ' - ', c.nome) as modalidade_completa
        FROM lotes_inscricao li
        LEFT JOIN eventos e ON li.evento_id = e.id
        LEFT JOIN modalidades m ON li.modalidade_id = m.id
        LEFT JOIN categorias c ON m.categoria_id = c.id
        WHERE li.id = ? AND li.evento_id IN (
            SELECT id FROM eventos WHERE organizador_id = ?
        )
    ");
    $stmt->execute([$lote_id, $_SESSION['user_id']]);
    $lote = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$lote) {
        throw new Exception('Lote não encontrado ou não autorizado');
    }

    // Formatar dados (estrutura otimizada)
    $loteFormatado = [
        'id' => $lote['id'],
        'evento_id' => $lote['evento_id'],
        'evento_nome' => $lote['evento_nome'],
        'modalidade_id' => $lote['modalidade_id'],
        'modalidade_nome' => $lote['modalidade_nome'],
        'categoria_nome' => $lote['categoria_nome'],
        'modalidade_completa' => $lote['modalidade_completa'],
        'numero_lote' => $lote['numero_lote'],
        'tipo_publico' => $lote['tipo_publico'],
        'tipo_publico_formatado' => $lote['tipo_publico'] === 'comunidade_academica' ? 'Comunidade Acadêmica' : 'Público Geral',
        'preco' => $lote['preco'],
        'preco_formatado' => 'R$ ' . number_format($lote['preco'], 2, ',', '.'),
        'preco_por_extenso' => $lote['preco_por_extenso'],
        'data_inicio' => $lote['data_inicio'],
        'data_fim' => $lote['data_fim'],
        'data_inicio_formatada' => date('d/m/Y', strtotime($lote['data_inicio'])),
        'data_fim_formatada' => date('d/m/Y', strtotime($lote['data_fim'])),
        'vagas_disponiveis' => $lote['vagas_disponiveis'],
        'taxa_servico' => $lote['taxa_servico'],
        'taxa_formatada' => $lote['taxa_servico'] > 0 ? 'R$ ' . number_format($lote['taxa_servico'], 2, ',', '.') : 'Não há',
        'quem_paga_taxa' => $lote['quem_paga_taxa'],
        'quem_paga_taxa_formatado' => $lote['quem_paga_taxa'] === 'organizador' ? 'Organizador' : 'Participante',
        'idade_min' => $lote['idade_min'],
        'idade_max' => $lote['idade_max'],
        'faixa_etaria' => $lote['idade_min'] . ' a ' . $lote['idade_max'] . ' anos',
        'desconto_idoso' => (bool)$lote['desconto_idoso'],
        'desconto_idoso_formatado' => $lote['desconto_idoso'] ? 'Sim' : 'Não',
        'ativo' => (bool)$lote['ativo'],
        'created_at' => $lote['created_at'],
        'updated_at' => $lote['updated_at']
    ];

    error_log("✅ API lotes-inscricao/get.php - Retornando dados do lote ID: $lote_id");

    echo json_encode([
        'success' => true,
        'lote' => $loteFormatado
    ]);

} catch (Exception $e) {
    error_log("💥 Erro ao buscar lote: " . $e->getMessage());
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?> 
