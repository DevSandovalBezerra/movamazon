<?php
header('Content-Type: application/json');
require_once '../../db.php';

session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['papel'] !== 'organizador') {
    http_response_code(401);
    echo json_encode(['error' => 'Acesso negado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método não permitido']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('Dados inválidos');
    }
    
    // Extrair dados básicos do kit
    $kit_id = isset($input['id']) ? (int)$input['id'] : 0;
    $nome = isset($input['nome']) ? trim($input['nome']) : '';
    $descricao = isset($input['descricao']) ? trim($input['descricao']) : '';
    $valor = isset($input['valor']) ? (float)$input['valor'] : 0;
    $ativo = isset($input['ativo']) ? (int)$input['ativo'] : 1;
    $modalidades = isset($input['modalidades']) && is_array($input['modalidades']) ? $input['modalidades'] : [];
    
    // Extrair produtos e tamanhos
    $produtos = isset($input['produtos']) ? $input['produtos'] : [];
    $tamanhos = isset($input['tamanhos']) ? $input['tamanhos'] : [];
    
    // Validações
    if ($kit_id <= 0) {
        throw new Exception('ID do kit é obrigatório');
    }
    if (empty($nome)) {
        throw new Exception('Nome do kit é obrigatório');
    }
    if ($valor <= 0) {
        throw new Exception('Valor deve ser maior que zero');
    }
    if (empty($produtos)) {
        throw new Exception('Pelo menos um produto deve ser selecionado');
    }
    $organizador_id = $_SESSION['user_id'];
    // Verificar se o kit existe e pertence ao organizador
    $stmt = $pdo->prepare("
        SELECT k.id, k.nome, k.evento_id, e.nome as evento_nome
        FROM kits_eventos k
        INNER JOIN eventos e ON k.evento_id = e.id
        WHERE k.id = ? AND e.organizador_id = ?
    ");
    $stmt->execute([$kit_id, $organizador_id]);
    $kit = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$kit) {
        throw new Exception('Kit não encontrado ou não pertence a você');
    }
    // Verificar se já existe outro kit com o mesmo nome para o mesmo evento
    $stmt = $pdo->prepare("
        SELECT id FROM kits_eventos 
        WHERE evento_id = ? AND nome = ? AND id != ?
    ");
    $stmt->execute([$kit['evento_id'], $nome, $kit_id]);
    if ($stmt->fetch()) {
        throw new Exception('Já existe outro kit com este nome para este evento');
    }
    // Iniciar transação
    $pdo->beginTransaction();
    // Atualizar dados básicos do kit
    $stmt = $pdo->prepare("
        UPDATE kits_eventos 
        SET nome = ?, descricao = ?, valor = ?, ativo = ?
        WHERE id = ?
    ");
    $stmt->execute([$nome, $descricao, $valor, $ativo, $kit_id]);
    // Atualizar modalidades associadas
    $pdo->prepare("DELETE FROM kit_modalidade_evento WHERE kit_id = ?")->execute([$kit_id]);
    if (!empty($modalidades)) {
        $stmt = $pdo->prepare("INSERT INTO kit_modalidade_evento (kit_id, modalidade_evento_id) VALUES (?, ?)");
        foreach ($modalidades as $mod_id) {
            $stmt->execute([$kit_id, $mod_id]);
        }
    }
    // Remover produtos existentes do kit
    $stmt = $pdo->prepare("UPDATE kit_produtos SET ativo = 0 WHERE kit_id = ?");
    $stmt->execute([$kit_id]);
    // Remover tamanhos existentes do kit
    $stmt = $pdo->prepare("UPDATE kit_tamanhos SET ativo = 0 WHERE kit_id = ?");
    $stmt->execute([$kit_id]);
    // Inserir novos produtos do kit
    foreach ($produtos as $index => $produto) {
        $produto_id = (int)$produto['produto_id'];
        $quantidade = isset($produto['quantidade']) ? (int)$produto['quantidade'] : 1;
        $tamanho_id = isset($produto['tamanho_id']) ? (int)$produto['tamanho_id'] : null;
        $ordem = $index + 1;
        $stmt = $pdo->prepare("SELECT id FROM produtos WHERE id = ?");
        $stmt->execute([$produto_id]);
        if (!$stmt->fetch()) {
            throw new Exception('Produto não encontrado');
        }
        $stmt = $pdo->prepare("
            INSERT INTO kit_produtos (kit_id, produto_id, tamanho_id, quantidade, ordem, ativo)
            VALUES (?, ?, ?, ?, ?, 1)
        ");
        $stmt->execute([$kit_id, $produto_id, $tamanho_id, $quantidade, $ordem]);
    }
    // Inserir novos tamanhos disponíveis para o kit (se houver camisetas)
    if (!empty($tamanhos)) {
        foreach ($tamanhos as $tamanho) {
            $tamanho_id = (int)$tamanho['tamanho_id'];
            $quantidade_disponivel = (int)$tamanho['quantidade_disponivel'];
            $stmt = $pdo->prepare("
                SELECT id FROM tamanhos_camisetas_evento 
                WHERE id = ? AND evento_id = ?
            ");
            $stmt->execute([$tamanho_id, $kit['evento_id']]);
            if (!$stmt->fetch()) {
                throw new Exception('Tamanho não encontrado ou não pertence ao evento');
            }
            $stmt = $pdo->prepare("
                INSERT INTO kit_tamanhos (kit_id, tamanho_id, quantidade_disponivel, quantidade_vendida, ativo, data_criacao)
                VALUES (?, ?, ?, 0, 1, NOW())
            ");
            $stmt->execute([$kit_id, $tamanho_id, $quantidade_disponivel]);
        }
    }
    $pdo->commit();
    error_log("Kit atualizado - ID: $kit_id, Nome: $nome, Evento: {$kit['evento_nome']}, Organizador: $organizador_id");
    echo json_encode([
        'success' => true,
        'message' => 'Kit atualizado com sucesso',
        'data' => [
            'id' => $kit_id,
            'nome' => $nome,
            'descricao' => $descricao,
            'valor' => $valor,
            'ativo' => $ativo
        ]
    ]);
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('Erro ao atualizar kit: ' . $e->getMessage());
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}
?> 
