<?php
session_start();
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../security_middleware.php';
require_once __DIR__ . '/../helpers/organizador_context.php';

// Contexto do organizador (organizador_id padrão + usuario_id legado)
$ctx = requireOrganizadorContext($pdo);
$usuario_id = $ctx['usuario_id'];
$organizador_id = $ctx['organizador_id'];

header('Content-Type: application/json; charset=utf-8');

try {
    $response = ['success' => true];

    // Gráfico 1: Inscrições por modalidade (agregado de todos os eventos)
    $sql_modalidades = "SELECT m.nome, COUNT(i.id) as total 
                        FROM inscricoes i 
                        JOIN modalidades m ON i.modalidade_evento_id = m.id 
                        JOIN eventos e ON i.evento_id = e.id
                        WHERE (e.organizador_id = ? OR e.organizador_id = ?) AND i.status = 'confirmada' AND e.deleted_at IS NULL
                        GROUP BY m.nome
                        ORDER BY total DESC";
    $stmt = $pdo->prepare($sql_modalidades);
    $stmt->execute([$organizador_id, $usuario_id]);
    $response['inscricoesPorModalidade'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Gráfico 2: Receita por período (inscrições por dia nos últimos 30 dias)
    $sql_receita = "SELECT DATE(i.data_inscricao) as dia, 
                           COUNT(i.id) as total_inscricoes,
                           SUM(i.valor_total) as receita_total
                    FROM inscricoes i 
                    JOIN eventos e ON i.evento_id = e.id
                    WHERE (e.organizador_id = ? OR e.organizador_id = ?) 
                      AND i.status = 'confirmada' 
                      AND e.deleted_at IS NULL
                      AND i.data_inscricao >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                    GROUP BY dia 
                    ORDER BY dia ASC";
    $stmt = $pdo->prepare($sql_receita);
    $stmt->execute([$organizador_id, $usuario_id]);
    $response['receitaPorPeriodo'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($response);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro no servidor: ' . $e->getMessage()]);
}
