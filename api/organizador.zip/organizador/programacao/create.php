<?php
header('Content-Type: application/json');
require_once '../../db.php';
require_once __DIR__ . '/../../helpers/organizador_context.php';

session_start();

error_log('API programacao/create.php - Início');

if (!isset($_SESSION['user_id']) || !isset($_SESSION['papel']) || $_SESSION['papel'] !== 'organizador') {
    error_log('API programacao/create.php - Acesso negado: user_id=' . ($_SESSION['user_id'] ?? 'null') . ', papel=' . ($_SESSION['papel'] ?? 'null'));
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Acesso negado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    error_log('API programacao/create.php - Método não permitido: ' . $_SERVER['REQUEST_METHOD']);
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Método não permitido']);
    exit;
}

try {
    error_log('API programacao/create.php - Try block');
    $ctx = requireOrganizadorContext($pdo);
    $usuario_id = $ctx['usuario_id'];
    $organizador_id = $ctx['organizador_id'];
    $data = json_decode(file_get_contents('php://input'), true);
    error_log('API programacao/create.php - Dados recebidos: ' . print_r($data, true));
    
    $evento_id = $data['evento_id'] ?? null;
    $nome = $data['nome'] ?? '';
    $hora_inicio = $data['hora_inicio'] ?? '';
    $hora_fim = $data['hora_fim'] ?? '';
    $local = $data['local'] ?? '';
    $descricao = $data['descricao'] ?? '';
    
    if (!$evento_id || !$nome || !$hora_inicio || !$hora_fim) {
        error_log('API programacao/create.php - Campos obrigatórios faltando');
        echo json_encode(['success' => false, 'error' => 'Todos os campos obrigatórios devem ser preenchidos']);
        exit;
    }
    
    // Verificar se o evento pertence ao organizador e não está excluído
    $sql = "SELECT id FROM eventos WHERE id = ? AND (organizador_id = ? OR organizador_id = ?) AND deleted_at IS NULL";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$evento_id, $organizador_id, $usuario_id]);
    
    if (!$stmt->fetch()) {
        error_log('API programacao/create.php - Evento não encontrado, foi excluído ou não pertence ao organizador');
        echo json_encode(['success' => false, 'error' => 'Evento não encontrado, foi excluído ou não pertence ao organizador']);
        exit;
    }
    
    // Verificar se há conflito de horário
    $sql = "SELECT id FROM programacao_evento 
            WHERE evento_id = ? AND 
                  ((hora_inicio <= ? AND hora_fim > ?) OR 
                   (hora_inicio < ? AND hora_fim >= ?) OR
                   (hora_inicio >= ? AND hora_fim <= ?))";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$evento_id, $hora_inicio, $hora_inicio, $hora_fim, $hora_fim, $hora_inicio, $hora_fim]);
    
    if ($stmt->fetch()) {
        error_log('API programacao/create.php - Conflito de horário detectado');
        echo json_encode(['success' => false, 'error' => 'Existe conflito de horário com outra atividade']);
        exit;
    }
    
    // Inserir item de programação
    error_log('API programacao/create.php - Inserindo item de programação');
    $sql = "INSERT INTO programacao_evento (evento_id, nome, hora_inicio, hora_fim, local, descricao) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$evento_id, $nome, $hora_inicio, $hora_fim, $local, $descricao]);
    
    $programacao_id = $pdo->lastInsertId();
    error_log('API programacao/create.php - Item criado com id: ' . $programacao_id);
    
    echo json_encode([
        'success' => true, 
        'message' => 'Item de programação criado com sucesso',
        'data' => ['id' => $programacao_id]
    ]);
    
} catch (Exception $e) {
    error_log('API programacao/create.php - Exceção: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Erro interno do servidor: ' . $e->getMessage()]);
}
?> 
